// dom helper
function $(selector, ifArr){
	if(ifArr) return document.querySelectorAll(selector);
	return document.querySelector(selector);
}

// entry point
window.onload = function(){
	var header = $('header');
	var ul = $('#listRoot');
	var form = {};
	form.root = $('form');
	form.input = $('#todo');
	form.addBtn = $('button');
	var tool = {};
	tool.root = $('#tools');
	tool.top = $('#tools i', true)[0];
	tool.up = $('#tools i', true)[1];
	tool.down = $('#tools i', true)[2];
	tool.bottom = $('#tools i', true)[3];
	var toTopBtn = $('#toTop');

	// sample data
	var listData = ['Turkey', 'Apple Pie', 'Chips', 'Blue Berry Jam', 'Chocolate Cake', 'Orange Juice'];

	// other global variable
	var timer;
	
	// use sample data to generate a default list
	for(var i=0, j=listData.length; i<j; i++){
		createLi(ul, listData[i]);
	}
	// add customed list item
	form.addBtn.onclick = function(){
		if(form.input.value){
			createLi(ul, form.input.value, true);
		}
		return false;
	};

	// hover to highlight adjacent siblings
	ul.onmouseover = function(e){
		var el = e.target;
		if(el.tagName == 'LI'){
			// remove any current hoverSib
			removeCls(ul, 'hoverSib');
			// add new hoverSib
			if(el.previousElementSibling) 
				el.previousElementSibling.className += ' hoverSib';
			if(el.nextElementSibling) 
				el.nextElementSibling.className += ' hoverSib';
		}
	};
	// remove all highlighted siblings on mouseleave
	ul.onmouseout = function(e){
		var el = e.target;
		if(el.tagName == 'LI'){
			// remove any current hoverSib
			removeCls(ul, 'hoverSib');
		}
	};
	// focus on a li when clicked, toggle the active status of the tool-panel
	ul.addEventListener('click', function(e){
		var el = e.target; 
		if(el.tagName == 'LI'){
			// remove any current focused li (if equals the clicked li, toggle)
			if(removeCls(ul, 'focus')[0] == el) {
				tool.root.className = '';
				return;
			}
			// add new focused li
			el.className += ' focus';
			tool.root.className = 'active';
		}
	}, false);

	// using the tool-panel to move li items
	tool.top.onclick = tool.bottom.onclick = function(e){
		var el = $('.focus');
		if(el){
			ul.insertBefore(el, e.target == tool.top ? ul.firstElementChild : null);
		}
	};
	tool.up.onclick = function(){
		moveUp($('.focus'));
	};
	tool.down.onclick = function(){
		moveDown($('.focus'));
	};

	// list specific tools
	ul.addEventListener('click', function(e){
		var el = e.target; 
		if(el.tagName == 'I'){
			var clsName = el.className;
			var li = el.parentNode;
			switch(true){
				// move up and down using list icon
				case clsName.indexOf('icon-arrow-circle-down') != -1:
						moveDown(li); break;
				case clsName.indexOf('icon-arrow-circle-up') != -1:
						moveUp(li); break;
				// remove an list item
				case clsName.indexOf('icon-trash2') != -1: 
						ul.removeChild(li); break;
				// toggle the blank/done status of the item
				case clsName.indexOf('icon-blank') != -1:
						el.className = 'icon-done'; 
						li.className += ' done';
						break;
				case clsName.indexOf('icon-done') != -1:
						el.className = 'icon-blank'; 
						li.className = li.className.split('done').join(' ').trim();
						break;
				// toggle star icon's active status
				case clsName.indexOf('icon-star') != -1:
						el.className = clsName.indexOf('active') != -1 ? 'icon-star' : 'icon-star active';
						break;
			}
		}
	}, false);

	// goto top button
	window.onscroll = function(){
		var scrollTop = document.body.scrollTop;
		// hide and show toTopBtn
		toTopBtn.style.opacity = scrollTop >= 140 ? 1 : 0;
	}

	toTopBtn.onclick = function(){
		clearInterval(timer);
		if(toTopBtn.style.opacity ==1){
			timer = setInterval(function(){
				document.body.scrollTop -= 10;
				if(document.body.scrollTop <= 0) clearInterval(timer);
			}, 10);
		}
	}

	// ----- task handlers -----
	// use list template to create new list item
	function createLi(el, item, insert){
		var li = document.createElement('li');
		var icons;
		var tpl = '<i class="icon-blank"></i>'
		      		+ '<i class="icon-star"></i>'
		      		+ '<span>' + item + '</span>'
			        + '<i class="fr icon-trash2"></i>'
		    		+ '<i class="fr icon-arrow-circle-down"></i>'
		    		+ '<i class="fr icon-arrow-circle-up"></i>';
	    li.innerHTML = tpl;
	    el.insertBefore(li, insert ? el.firstElementChild : null);
	    // attach icons to the li
	    icons = li.querySelectorAll('i');
	    li.todo = icons[0];
	    li.star = icons[1];
	    li.trash = icons[2];
	    li.down = icons[3];
	    li.up = icons[4];
	}

	// loop and remove certain className
	function removeCls(context, clsName){
		var elems = context.querySelectorAll('.' + clsName);
		if(elems.length != 0){
			for(var i=0, j=elems.length; i<j; i++){
				elems[i].className = elems[i].className.split(clsName).join(' ').trim();
			}
		}
		return elems;
	}

	// to move up/down an item in ul
	function moveUp(el){
		if(el && el.previousElementSibling)
			ul.insertBefore(el, el.previousElementSibling);
	}
	function moveDown(el){
		if(el && el.nextElementSibling)
			ul.insertBefore(el.nextElementSibling, el);
	}
};
